using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Remote : MonoBehaviour
{
    private Vector3 mousePosition;
    private bool isDragging = false;

    void OnMouseDown()
    {
        isDragging = true;
    }

    void OnMouseUp()
    {
        isDragging = false;
    }

    void Update()
    {
        if (isDragging)
        {
            Cursor.visible = true;
            SceneManager.LoadScene("WinningScene");
        }
    }
}