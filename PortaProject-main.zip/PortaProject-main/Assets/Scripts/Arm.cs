using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arm : MonoBehaviour
{
    private Vector3 mousePosition;
    public float moveSpeed = 0.1f;
    [SerializeField] AudioSource stretchSound;
    [SerializeField] AudioClip[] randomAudios; // Array to hold your random audio clips
    private bool shouldPlayStretch;
    float minX;
    float minY;
    float maxX;
    float maxY;


    void Start()
    {
        minY = -4.5f;
        maxY = 4.5f;
        minX = -8.61f;
        maxX = 8.61f;
    }

    void Update()
    {
        mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);
        if (mousePosition.x > maxX)
            mousePosition.x = maxX;
        else if (mousePosition.x < minX)
            mousePosition.x = minX;
        if (mousePosition.y > maxY)
            mousePosition.y = maxY;
        else if (mousePosition.y < minY)
            mousePosition.y = minY;
        transform.position = Vector2.Lerp(transform.position, mousePosition, moveSpeed);


        // Check if the arm's y position exceeds 4
        if (mousePosition.y > 4)
        {
            shouldPlayStretch = true;
        }

        // If the condition is met and the sound is not already playing, play a random audio
        if (shouldPlayStretch && !stretchSound.isPlaying)
        {
            // Choose a random audio clip from the array
            AudioClip randomClip = randomAudios[Random.Range(0, randomAudios.Length)];
            stretchSound.clip = randomClip;
            stretchSound.Play();
            shouldPlayStretch = false;
        }
    }
}