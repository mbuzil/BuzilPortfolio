using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arm2 : MonoBehaviour
{
    [SerializeField] Sprite handOpen;
    [SerializeField] Sprite handClosed;

    SpriteRenderer spriteRenderer;

    void Awake()
    {
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        if (Input.GetKey(KeyCode.Mouse0))
            spriteRenderer.sprite = handClosed;
        else
            spriteRenderer.sprite = handOpen;
    }
}
