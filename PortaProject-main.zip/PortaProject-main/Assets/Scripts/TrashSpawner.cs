using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrashSpawner : MonoBehaviour
{
    public GameObject[] prefabsToSpawn; // List of prefabs to spawn
    public int spawnCount = 5; // Number of times each prefab should be spawned
    public Vector2 spawnArea = new Vector2(5f, 5f); // Size of the spawn area
    public GameObject remote;
    public bool remoteExists;
    private float currentZValue = -10f; // Starting z value for spawned items

    void Start()
    {
        remoteExists = false;
        SpawnPrefabs();
    }

    void SpawnPrefabs()
    {
        foreach (GameObject prefab in prefabsToSpawn)
        {
            for (int i = 0; i < spawnCount; i++)
            {
                // Calculate random position within the spawn area
                float randomX = Random.Range(-spawnArea.x / 2f, spawnArea.x / 2f);
                float randomY = Random.Range(-spawnArea.y / 2f, spawnArea.y / 2f);
                Vector3 spawnPosition = new Vector3(randomX, randomY, 0f) + transform.position;

                // Calculate random rotation
                Quaternion randomRotation = Quaternion.Euler(0f, 0f, Random.Range(0f, 360f));

                // Spawn the prefab at the calculated position with random rotation
                GameObject spawnedPrefab = Instantiate(prefab, spawnPosition, randomRotation);

                // Set the `z` position for the spawned item
                spawnedPrefab.transform.position = new Vector3(spawnedPrefab.transform.position.x, spawnedPrefab.transform.position.y, currentZValue);

                // Increment the `currentZValue` for the next item
                currentZValue += 1f;

                // Parent the spawned prefab to this GameObject for organization
                spawnedPrefab.transform.SetParent(transform);
            }
        }

        // Handle spawning the remote object
        if (!remoteExists)
        {
            float randomX = Random.Range(-spawnArea.x / 2f, spawnArea.x / 2f);
            float randomY = Random.Range(-spawnArea.y / 2f, spawnArea.y / 2f);
            Vector3 spawnPosition = new Vector3(randomX, randomY, 0f) + transform.position;
            Quaternion randomRotation = Quaternion.Euler(0f, 0f, Random.Range(0f, 360f));

            GameObject spawnedPrefab = Instantiate(remote, spawnPosition, randomRotation);

            // Set the `z` position for the remote object
            spawnedPrefab.transform.position = new Vector3(spawnedPrefab.transform.position.x, spawnedPrefab.transform.position.y, currentZValue);

            // Increment the `currentZValue` for the next item
            currentZValue += 1f;

            // Parent the spawned prefab to this GameObject for organization
            spawnedPrefab.transform.SetParent(transform);

            remoteExists = true;
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(transform.position, new Vector3(spawnArea.x, spawnArea.y, 0f));
    }
}