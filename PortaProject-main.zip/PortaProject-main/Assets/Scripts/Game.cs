using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public AudioClip mainSceneMusic; // Main scene music clip
    public AudioClip alternateMusic; // Alternate music clip after 32 seconds
    private AudioSource mainAudioSource; // AudioSource for main scene music
    private AudioSource alternateAudioSource; // AudioSource for alternate music
    private float elapsedTime = 0f; // Timer to keep track of time

    void Start()
    {
        // Hide the cursor
        Cursor.visible = false;

        // Initialize AudioSource components
        mainAudioSource = gameObject.AddComponent<AudioSource>();
        alternateAudioSource = gameObject.AddComponent<AudioSource>();

        // Set the audio sources' clips and loop properties
        mainAudioSource.clip = mainSceneMusic;
        mainAudioSource.loop = true;

        alternateAudioSource.clip = alternateMusic;
        alternateAudioSource.loop = true;

        // Check if the current scene is "Main"
        if (IsMainScene())
        {
            // Play the main scene music
            mainAudioSource.Play();
        }
        else
        {
            // Stop the audio sources if not in "Main"
            StopAudio();
        }
    }

    void Update()
    {
        // Check if the current scene is "Main"
        if (IsMainScene())
        {
            // Update the elapsed time
            elapsedTime += Time.deltaTime;

            // Check if 32 seconds have passed
            if (elapsedTime >= 32f)
            {
                // Play the alternate music if not already playing
                if (!alternateAudioSource.isPlaying)
                {
                    alternateAudioSource.Play();
                }
            }
        }
        else
        {
            // Stop both audio sources if not in "Main"
            StopAudio();
        }
    }

    // Helper method to check if the current scene is "Main"
    bool IsMainScene()
    {
        string currentSceneName = SceneManager.GetActiveScene().name;
        return currentSceneName == "Main";
    }

    // Helper method to stop both audio sources
    void StopAudio()
    {
        mainAudioSource.Stop();
        alternateAudioSource.Stop();
    }
}