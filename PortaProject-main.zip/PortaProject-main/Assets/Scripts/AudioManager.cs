using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AudioManager : MonoBehaviour
{
    public AudioSource audioSource; // The AudioSource component to manage
    private string[] allowedScenes = { "Start", "FirstNext", "SecondNext"}; // List of allowed scene names

    private static AudioManager instance;

    void Awake()
    {
        // Ensure only one instance of the AudioManager exists
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject); // Destroy duplicate instances
            return;
        }
    }

    void OnLevelWasLoaded(int level)
    {
        // Check the current scene name
        string currentSceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;

        // Determine if the current scene is one of the allowed scenes
        bool isAllowedScene = System.Array.Exists(allowedScenes, scene => scene == currentSceneName);

        // Play or stop audio based on the scene
        if (isAllowedScene)
        {
            // Only play the audio if it is not already playing
            if (!audioSource.isPlaying)
            {
                audioSource.Play();
            }
        }
        else
        {
            // Stop the audio if the current scene is not in the allowed list
            audioSource.Stop();
        }
    }
}