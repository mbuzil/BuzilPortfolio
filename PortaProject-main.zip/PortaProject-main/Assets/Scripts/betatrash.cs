using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class betatrash : MonoBehaviour
{
    private Vector3 mousePosition;
    private bool isDragging = false;
    public float moveSpeed = 0.1f;
    public AudioClip[] grabSounds;
    private AudioSource audioSource;
    private GameObject selectedItem = null; // Selected item
    private Vector3 initialOffset;
    private int currentSortingOrder = 0; // Global sorting order counter

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (isDragging)
        {
            MoveSelectedItem();
        }

        if (Input.GetMouseButtonDown(0)) // Left mouse button pressed
        {
            SelectTopItem();
        }
        else if (Input.GetMouseButtonUp(0)) // Left mouse button released
        {
            OnMouseUp();
        }
    }

    void OnMouseDown()
    {
        PlayRandomGrabSound();
    }

    void OnMouseUp()
    {
        isDragging = false;
        selectedItem = null;
    }

    void MoveSelectedItem()
    {
        if (selectedItem)
        {
            mousePosition = Input.mousePosition;
            mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

            // Update the selected item's position based on the mouse position
            Vector3 targetPosition = mousePosition + initialOffset;
            selectedItem.transform.position = Vector2.Lerp(selectedItem.transform.position, targetPosition, moveSpeed);
        }
    }

    void PlayRandomGrabSound()
    {
        if (grabSounds.Length > 0)
        {
            int randomIndex = Random.Range(0, grabSounds.Length);
            audioSource.clip = grabSounds[randomIndex];
            audioSource.Play();
        }
    }

    void SelectTopItem()
    {
        // Determine the mouse position in the world
        Vector3 worldMousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // Perform an overlap check at the mouse position
        Collider2D[] hits = Physics2D.OverlapPointAll(worldMousePosition);

        // Initialize the highest sorting order to a very low value
        int highestSortingOrder = int.MinValue;
        GameObject topMostObject = null;

        // Iterate through all hits to find the top-most object based on sorting order
        foreach (Collider2D hit in hits)
        {
            GameObject hitObject = hit.gameObject;
            SpriteRenderer spriteRenderer = hitObject.GetComponent<SpriteRenderer>();

            if (spriteRenderer != null && spriteRenderer.sortingOrder > highestSortingOrder)
            {
                highestSortingOrder = spriteRenderer.sortingOrder;
                topMostObject = hitObject;
            }
        }

        // If a top-most object was found, select it
        if (topMostObject != null)
        {
            selectedItem = topMostObject;
            isDragging = true;

            // Calculate the initial offset between the mouse and the selected item
            initialOffset = selectedItem.transform.position - worldMousePosition;

            // Ensure the selected item is in front of everything else
            currentSortingOrder++;

            // Update the sorting order of the selected item to be the highest
            SpriteRenderer spriteRenderer = selectedItem.GetComponent<SpriteRenderer>();
            if (spriteRenderer != null)
            {
                spriteRenderer.sortingOrder = currentSortingOrder;
            }
        }
    }
}