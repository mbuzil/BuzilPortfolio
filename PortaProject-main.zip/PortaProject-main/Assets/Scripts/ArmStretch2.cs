using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmStretch2 : MonoBehaviour
{
    [SerializeField] SpriteRenderer sprite;
    float minX;
    float minY;
    float maxX;
    float maxY;

    void Start()
    {
        sprite.drawMode = SpriteDrawMode.Sliced;
        minY = -4.5f;
        maxY = 4.5f;
        minX = -8.61f;
        maxX = 8.61f;
    }
    // Update is called once per frame
    void Update()
    {

        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        if (mousePos.x > maxX)
            mousePos.x = maxX;
        else if (mousePos.x < minX)
            mousePos.x = minX;
        if (mousePos.y > maxY)
            mousePos.y = maxY;
        else if (mousePos.y < minY)
            mousePos.y = minY;
        if (mousePos.x < 0)
            mousePos.x += 2.13f * 1.5f;
        else
            mousePos.x += 2.13f * 0.6f;
        mousePos.y -= 2.01f * 1.65f;
        float distance = Mathf.Abs(Vector2.Distance(mousePos, this.transform.position));

        sprite.size = new Vector2(distance, sprite.size.y);
    }
}
