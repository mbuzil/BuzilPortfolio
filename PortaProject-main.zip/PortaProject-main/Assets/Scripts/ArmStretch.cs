using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmStretch : MonoBehaviour
{

    // Update is called once per frame
    void Update()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.x += 2.13f;
        mousePos.y -= 2.01f;
        transform.rotation = Quaternion.LookRotation(Vector3.forward, mousePos - transform.position);
    }
}
