using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{
    public void Retry()
    {
        SceneManager.LoadScene("Start");
    }
    public void start()
    {
        SceneManager.LoadScene("FirstNext");
    }
    public void exit()
    {
        Application.Quit();
    }
    public void firstNext()
    {
        SceneManager.LoadScene("SecondNext");
    }
    public void secondNext()
    {
        SceneManager.LoadScene("Main");
    }
    public void backToMenu()
    {
        SceneManager.LoadScene("Start");
    }

}
