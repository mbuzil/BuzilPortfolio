using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CountDown : MonoBehaviour
{
    public float countdownTime = 38f; // Initial countdown time
    public TMP_Text countdownText; // Text View

    void Start()
    {
        // Start the countdown
        InvokeRepeating("UpdateCountdown", 0f, 1f); // Call UpdateCountdown every second
    }

    void UpdateCountdown()
    {
        countdownTime -= 1f; // Decrease countdown time
        UpdateUI(); // Update UI text

        if (countdownTime <= 0)
        {
            // Load losing scene when countdown reaches zero
            //Add this back when LosingScene is added
            Cursor.visible = true;
            SceneManager.LoadScene("LoosingScreen");
        }
    }

    void UpdateUI()
    {
        // Update UI text to display current countdown time
        countdownText.text = "Where is the remote? I have " + Mathf.Round(countdownTime) + " seconds until my favorite TV show starts!";
    }
}