using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WinningMusic : MonoBehaviour
{
    public AudioClip WinningSceneMusic; // The audio clip to play in the LosingScene
    private AudioSource audioSource;

    void Start()
    {
        // Get the AudioSource component attached to this GameObject
        audioSource = GetComponent<AudioSource>();

        // If an audio clip is assigned and the AudioSource is ready, play the losing scene music
        if (WinningSceneMusic != null)
        {
            audioSource.clip = WinningSceneMusic;
            audioSource.loop = true; // Set to loop the audio if you want it to repeat continuously
            audioSource.Play();
        }
    }

    // This method is called when the script or GameObject is destroyed
    void OnDestroy()
    {
        // Stop the audio when leaving the scene
        if (audioSource != null && audioSource.isPlaying)
        {
            audioSource.Stop();
        }
    }
}