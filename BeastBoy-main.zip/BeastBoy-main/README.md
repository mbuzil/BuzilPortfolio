# BeastBoy
Assets from
https://www.youtube.com/watch?v=7kd_62Lq72c

https://www.myinstants.com/en/instant/hitmarkermp3/#google_vignette

https://www.videvo.net/sound-effect/gun-shot-single-shot-in-pe1097906/246309/#rs=audio-download

Cassidy pixel spray from Overwatch Blizzard Entertainment

https://free3d.com/3d-model/polarbear-v2--715551.html

https://free3d.com/3d-model/cheetah-v3--134565.html

https://free3d.com/3d-model/gorilla-v2--985344.html

https://free3d.com/3d-model/bird-v1--875504.html

https://free3d.com/3d-model/t-rex-by-zino-25516.html

https://free3d.com/3d-model/colosseum-37887.html 
