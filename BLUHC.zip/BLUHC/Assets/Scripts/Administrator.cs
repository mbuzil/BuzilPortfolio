using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Administrator : MonoBehaviour
{
    [SerializeField] public Team[] teams;
    [SerializeField] TMP_Text txt;
    int selectedTeam = 0;

    [SerializeField] TMP_Text p1Name;
    [SerializeField] TMP_Text p1Helm;
    [SerializeField] TMP_Text p1Chest;
    [SerializeField] TMP_Text p1Leg;
    [SerializeField] TMP_Text p1Foot;
    [SerializeField] TMP_Text p1Hp;
    [SerializeField] TMP_Text p1Kills;
    [SerializeField] TMP_Text p2Name;
    [SerializeField] TMP_Text p2Helm;
    [SerializeField] TMP_Text p2Chest;
    [SerializeField] TMP_Text p2Leg;
    [SerializeField] TMP_Text p2Foot;
    [SerializeField] TMP_Text p2Hp;
    [SerializeField] TMP_Text p2Kills;
    [SerializeField] TMP_Text p3Name;
    [SerializeField] TMP_Text p3Helm;
    [SerializeField] TMP_Text p3Chest;
    [SerializeField] TMP_Text p3Leg;
    [SerializeField] TMP_Text p3Foot;
    [SerializeField] TMP_Text p3Hp;
    [SerializeField] TMP_Text p3Kills;
    
    public void nextTeam()
    {
        selectedTeam += 1;
        if(selectedTeam >= teams.Length)
        {
            selectedTeam = 0;
        }
    }

    void Update()
    {
        txt.text = teams[selectedTeam].teamName;
        p1Name.text = teams[selectedTeam].p1.ign;
        p1Helm.text = teams[selectedTeam].p1.inventory[0].itemName;
        p1Chest.text = teams[selectedTeam].p1.inventory[1].itemName;
        p1Leg.text = teams[selectedTeam].p1.inventory[2].itemName;
        p1Foot.text = teams[selectedTeam].p1.inventory[3].itemName;
        p1Hp.text = "HP: " + teams[selectedTeam].p1.hp.ToString();
        p1Kills.text = "Kills: " + teams[selectedTeam].p1.kills.ToString();

        p2Name.text = teams[selectedTeam].p2.ign;
        p2Helm.text = teams[selectedTeam].p2.inventory[0].itemName;
        p2Chest.text = teams[selectedTeam].p2.inventory[1].itemName;
        p2Leg.text = teams[selectedTeam].p2.inventory[2].itemName;
        p2Foot.text = teams[selectedTeam].p2.inventory[3].itemName;
        p2Hp.text = "HP: " + teams[selectedTeam].p2.hp.ToString();
        p2Kills.text = "Kills: " + teams[selectedTeam].p2.kills.ToString();

        p3Name.text = teams[selectedTeam].p3.ign;
        p3Helm.text = teams[selectedTeam].p3.inventory[0].itemName;
        p3Chest.text = teams[selectedTeam].p3.inventory[1].itemName;
        p3Leg.text = teams[selectedTeam].p3.inventory[2].itemName;
        p3Foot.text = teams[selectedTeam].p3.inventory[3].itemName;
        p3Hp.text = "HP: " + teams[selectedTeam].p3.hp.ToString();
        p3Kills.text = "Kills: " + teams[selectedTeam].p3.kills.ToString();
    }

    public Team getTeam()
    {
        return teams[selectedTeam];
    }

    public Team[] getTeams()
    {
        return teams;
    }

    public void delTeam(Team t)
    {
        Destroy(t);
        Debug.Log(t.teamName + " has been eliminated.");
    }

    public Player[] getPlayers()
    {
        Player[] playerList = new Player[(teams.Length)*3];
        int count = 0;
        for(int i = 0; i < teams.Length; i++)
        {
            playerList[count] = teams[i].p1;
            count++;
            playerList[count] = teams[i].p2;
            count++;
            playerList[count] = teams[i].p3;
            count++;
        }
        return playerList;
    }
}
