using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomEvents : MonoBehaviour
{
    Team t1;
    [SerializeField] GameObject admin;
    [SerializeField] GameObject loottable;


    void Update()
    {
        t1 = admin.GetComponent<Administrator>().getTeam();
    }

    public void Choose()
    {
        int events = Random.Range(1,15);
        if(events == 1)
            Fall();
        else if(events == 2)
            Hunger();
        else if(events == 3)
            Monster();
        else if(events == 4)
            Goat();
        else if(events == 5)
            Gravel();
        else if(events == 6 || events == 7)
            Village();
        else if(events == 8 || events == 9)
            Mineshaft();
        else if(events == 10)
            Pyramid();
        else
            Fighting();
    }

    public void Fall()
    {
        int dmg = 0;
        int p = Random.Range(1,4);
        int rng = Random.Range(1,3);
        if(rng == 3)
            dmg = Random.Range(1,21);
        else
            dmg = Random.Range(1,7);

        if(p == 1)
        {
            t1.p1.dealDMG(dmg);
            Debug.Log(t1.p1.ign + " has fallen and taken " + dmg + " damage.");
        }
        else if(p == 2)
        {
            t1.p2.dealDMG(dmg);
            Debug.Log(t1.p2.ign + " has fallen and taken " + dmg + " damage.");
        }
        else
        {
            t1.p3.dealDMG(dmg);
            Debug.Log(t1.p3.ign + " has fallen and taken " + dmg + " damage.");
        }

    }

    public void Hunger()
    {
        int dmg = 0;
        int p = Random.Range(1,4);
        int rng = Random.Range(1,3);
        if(rng == 3)
            dmg = Random.Range(1,21);
        else
            dmg = Random.Range(1,7);

        if(p == 1)
        {
            t1.p1.dealDMG(dmg);
            Debug.Log(t1.p1.ign + " has run out of food and taken " + dmg + " damage.");
        }
        else if(p == 2)
        {
            t1.p2.dealDMG(dmg);
            Debug.Log(t1.p2.ign + " has run out of food and taken " + dmg + " damage.");
        }
        else
        {
            t1.p3.dealDMG(dmg);
            Debug.Log(t1.p3.ign + " has run out of food and taken " + dmg + " damage.");
        }
    }

    public void Monster()
    {
        int dmg = 0;
        int p = Random.Range(1,4);
        int rng = Random.Range(1,3);
        if(rng == 3)
            dmg = Random.Range(1,21);
        else
            dmg = Random.Range(1,7);

        if(p == 1)
        {
            t1.p1.dealDMG(dmg);
            Debug.Log(t1.p1.ign + " has taken " + dmg + " damage from a monster.");
        }
        else if(p == 2)
        {
            t1.p2.dealDMG(dmg);
            Debug.Log(t1.p2.ign + " has taken " + dmg + " damage from a monster.");
        }
        else
        {
            t1.p3.dealDMG(dmg);
            Debug.Log(t1.p3.ign + " has taken " + dmg + " damage from a monster.");
        }
    }

    public void Goat()
    {
        int dmg = 0;
        int p = Random.Range(1,4);
        int rng = Random.Range(1,3);
        if(rng == 3)
            dmg = Random.Range(1,21);
        else
            dmg = Random.Range(1,7);

        if(p == 1)
        {
            t1.p1.dealDMG(dmg);
            Debug.Log(t1.p1.ign + " was knocked off a hill by a goat and took " + dmg + " damage.");
        }
        else if(p == 2)
        {
            t1.p2.dealDMG(dmg);
            Debug.Log(t1.p2.ign + " was knocked off a hill by a goat and took " + dmg + " damage.");
        }
        else
        {
            t1.p3.dealDMG(dmg);
            Debug.Log(t1.p3.ign + " was knocked off a hill by a goat and took " + dmg + " damage.");
        }
    }

    public void Gravel()
    {
        int p = Random.Range(1,4);
        int dmg = Random.Range(1,5);
        int block = Random.Range(1,3);
        string fBlock = "";
        if(block == 1)
            fBlock = "sand";
        else
            fBlock = "gravel";

        if(p == 1)
        {
            t1.p1.dealDMG(dmg);
            Debug.Log(t1.p1.ign + " was crushed by falling " + fBlock + " and took " + dmg + " damage.");
        }
        else if(p == 2)
        {
            t1.p2.dealDMG(dmg);
            Debug.Log(t1.p2.ign + " was crushed by falling " + fBlock + " and took " + dmg + " damage.");
        }
        else
        {
            t1.p3.dealDMG(dmg);
            Debug.Log(t1.p3.ign + " was crushed by falling " + fBlock + " and took " + dmg + " damage.");
        }
    }


    public void Village()
    {
        int golem = Random.Range(1,101);
        int p = Random.Range(1,4);
        int dmg = Random.Range(6,21);
        int loot = Random.Range(1,101);

        Debug.Log(t1.teamName + " is at a village");

        if(golem >= 92)
        {
            if(p == 1)
            {
                t1.p1.dealDMG(dmg);
                Debug.Log(t1.p1.ign + " tried to fight an Iron Golem and took " + dmg + " damage.");
            }
            else if(p == 2)
            {
                t1.p2.dealDMG(dmg);
                Debug.Log(t1.p2.ign + " tried to fight an Iron Golem and took " + dmg + " damage.");
            }
            else
            {
                t1.p3.dealDMG(dmg);
                Debug.Log(t1.p3.ign + " tried to fight an Iron Golem and took " + dmg + " damage.");
            }
        }
        Debug.Log("The loot coefficient is: " + loot);
        loottable.GetComponent<Lootering>().Looting(t1, 40, 70, 101, 102, loot);
    }
    
    public void Mineshaft()
    {
        int monter = Random.Range(1,11);
        int loot = Random.Range(1,101);
        
        Debug.Log(t1.teamName + " is at a mineshaft");

        if(monter > 7)
        {
            Monster();
        }

        if(monter < 3)
        {
            Gravel();
        }
        Debug.Log("The loot coefficient is: " + loot);
        loottable.GetComponent<Lootering>().Looting(t1, 0, 60, 101, 102, loot);
    }

    public void Pyramid()
    {
        int fallnum = Random.Range(1,11);
        int loot = Random.Range(1,101);

        Debug.Log(t1.teamName + " is at a Pyramid");

        if(fallnum == 10)
        {
            Fall();
        }

        loottable.GetComponent<Lootering>().Looting(t1, 0, 80, 90, 100, loot);
    }

    public void Fighting()
    {
        Team[] teamList = admin.GetComponent<Administrator>().teams;
        int rngesus = Random.Range(0,teamList.Length);
        while(teamList[rngesus].teamName == t1.teamName)
        {
            rngesus = Random.Range(0,teamList.Length);
        }
        int fighting = Random.Range(1,10);
        Debug.Log(t1.teamName + " has found " + teamList[rngesus].teamName);
        if(fighting > 4)
            Debug.Log(t1.teamName + " has engaged in combat (pls click the fight button)");
        else
            Debug.Log(t1.teamName + " has run away from " + teamList[rngesus].teamName);
    }
}
