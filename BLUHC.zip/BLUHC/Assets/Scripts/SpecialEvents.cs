using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialEvents : MonoBehaviour
{
	Team[] t1;
	[SerializeField] GameObject admin;
    [SerializeField] GameObject RE;
    [SerializeField] GameObject loottable;
    public Team[] cornlist;

    void Start()
    {
        t1 = admin.GetComponent<Administrator>().teams;
    }

    public void ChooseEvent()
    {
        Debug.Log("SPECIAL EVENT");
        int events = Random.Range(1,5);
        if(events == 1)
            Cornucopia();
        if(events == 2)
            Famine();
        if(events == 3)
            MonstersInc();
        if(events == 4)
            Thunderstorm();
    }

    public void Cornucopia()
    {
        Debug.Log("A giant Cornucopia opens in the center of the map!");
        int count = 0;
        int corn = Random.Range(1,4);
        int rng = Random.Range(1,101);
        cornlist = new Team[t1.Length];
        for(int i = 0; i < t1.Length; i++)
        {
            corn = Random.Range(1,4);
            if(corn != 5)
            {
                cornlist[count] = t1[i];
                count++;
                Debug.Log(t1[i].teamName + " has gone to the Cornucopia.");
            }
        }
        if(count > 0)
        {
        for(int i = 0; i < count; i++)
        {
            Debug.Log(cornlist[i]);
            loottable.GetComponent<Lootering>().Looting(cornlist[i], 0, 20, 45, 65, rng);
            rng = Random.Range(1,101);
        }
        Debug.Log("Make all teams in the Cornucopia fight eachother using the buttons: ");
        for(int i = 0; i < cornlist.Length; i++)
        {
            Debug.Log(cornlist[i].teamName);
        }
        }
        if(count == 0)
        {
            Debug.Log("Nobody went to the Cornucopia");
        }
    }

    public void Famine()
    {
        Debug.Log("A wide spread Famine wipes through the world, everyone gains the hunger effect");
        Player[] playerList = admin.GetComponent<Administrator>().getPlayers();
        int rng = Random.Range(1,11);
        int dmg = Random.Range(1,21);
        for(int i = 0; i < playerList.Length; i++)
        {
            if(rng > 4)
            {
                playerList[i].dealDMG(dmg);
                Debug.Log(playerList[i].ign + " took " + dmg + " damage from the famine!");
            }
            rng = Random.Range(1,11);
            dmg = Random.Range(1,21);
        }
    }

    public void MonstersInc()
    {
        Debug.Log("Monsters spawn Everywhere!");
        Player[] playerList = admin.GetComponent<Administrator>().getPlayers();
        int rng = Random.Range(1,11);
        int dmg = Random.Range(1,21);
        for(int i = 0; i < playerList.Length; i++)
        {
            if(rng > 6)
            {
                playerList[i].dealDMG(dmg);
                Debug.Log(playerList[i].ign + " took " + dmg + " damage from the Monsters!");
            }
            rng = Random.Range(1,11);
            dmg = Random.Range(1,21);
        }
    }

    public void Thunderstorm()
    {
        Debug.Log("A gaint Thunderstorm starts!");
        Player[] playerList = admin.GetComponent<Administrator>().getPlayers();
        int rng = Random.Range(1,11);
        int dmg = Random.Range(5,21);
        for(int i = 0; i < playerList.Length; i++)
        {
            if(rng == 5)
            {
                playerList[i].dealDMG(dmg);
                Debug.Log(playerList[i].ign + " took " + dmg + " damage from the Lightning!");
            }
            if(rng > 7)
            {
                playerList[i].dealDMG(dmg);
                Debug.Log(playerList[i].ign + " took " + dmg + " damage from the Fires!");
            }
            rng = Random.Range(1,11);
            dmg = Random.Range(1,21);
        }
    }

}
