using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
	public string ign;
	public int melee;
	public int archery;
	public int mining;

	public int hp = 20;
	public float armorCoefficient = 1f; //Act as like a GPA of armor. Take less damage the higher the coefficient. A perfect 5.0 is full netherite. Weighted average them together, so diamond chest + iron everything else is 3.4
	public bool alive = true;

	public Loot[] inventory;

	public int kills = 0;

	public void kill()
    {
        alive = false;
        melee = 0;
        archery = 0;
        mining = 0;
        hp = 0;
        Debug.Log(ign + " has died");
    }

	public void gotKill()
	{
		kills++;
		Debug.Log("Killed by: " + ign);
	}

	public void dealDMG(int n)
	{
		hp -= n;
		Debug.Log(ign + " took " + n + " damage.");
		if(hp <= 0)
		{
			kill();
		}
	}

	public void combatDMG(int n)
	{
		hp -= n;
		Debug.Log(ign + " took " + n + " damage.");
	}

	public void setArmorCoef()
	{
		int material = 0;
		int avgmat = 0;
		float mod = 0f;
		for(int i = 0; i < inventory.Length; i++)
		{
			material += inventory[i].resourceCoefficient;
			mod += inventory[i].lootCoefficient;
		}
		avgmat = material/inventory.Length;
		armorCoefficient = 1f;
		armorCoefficient += mod+avgmat;
	}

	public int getHelm()
	{
		return inventory[0].resourceCoefficient;
	}
	public int getChest()
	{
		return inventory[1].resourceCoefficient;
	}
	public int getLegs()
	{
		return inventory[2].resourceCoefficient;
	}
	public int getBoots()
	{
		return inventory[3].resourceCoefficient;
	}

	public void Give(Loot l)
	{
		if(l.itemType == "Helmet")
		{
			if(l.resourceCoefficient > getHelm())
			{
				inventory[0] = l;
				Debug.Log("Giving " + ign + " " + l.itemName);
			}
		}
		else if(l.itemType == "Chestplate")
		{
			if(l.resourceCoefficient > getChest())
			{
				inventory[1] = l;
				Debug.Log("Giving " + ign + " " + l.itemName);
			}
		}
		else if(l.itemType == "Leggings")
		{
			if(l.resourceCoefficient > getLegs())
			{
				inventory[2] = l;
				Debug.Log("Giving " + ign + " " + l.itemName);
			}
		}
		else
		{
			if(l.resourceCoefficient > getBoots())
			{
				inventory[3] = l;
				Debug.Log("Giving " + ign + " " + l.itemName);
			}
		}
		Debug.Log(ign + " got " + l.itemName);
	}

	public bool canGive(Loot l)
	{
		if(!alive)
			return false;
		if(l.itemType == "Helmet")
		{
			if(l.resourceCoefficient > getHelm())
			{
				return true;
			}
		}
		else if(l.itemType == "Chestplate")
		{
			if(l.resourceCoefficient > getChest())
			{
				return true;
			}
		}
		else if(l.itemType == "Leggings")
		{
			if(l.resourceCoefficient > getLegs())
			{
				return true;
			}
		}
		else
		{
			if(l.resourceCoefficient > getBoots())
			{
				return true;
			}
		}
		return false;
	}


}
