using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lootering : MonoBehaviour
{
    public Loot LH;
    public Loot LC;
    public Loot LL;
    public Loot LB;

    public Loot IH;
    public Loot IC;
    public Loot IL;
    public Loot IB;

    public Loot DH;
    public Loot DC;
    public Loot DL;
    public Loot DB;

    public Loot NH;
    public Loot NC;
    public Loot NL;
    public Loot NB;

    public Loot l1;
    public Loot l2;
    public Loot l3;

    public void Looting(Team t, int leather, int iron, int diamond, int netherite, int loot)
    {
        int rng = Random.Range(1,5);
        int rng2 = Random.Range(1,5);
        int rng3 = Random.Range(1,5);

        if(loot < leather)
        {
            if(rng == 1)
                l1 = LH;
            if(rng == 2)
                l1 = LC;
            if(rng == 3)
                l1 = LL;
            if(rng == 4)
                l1 = LB;
            
            if(rng2 == 1)
                l2 = LH;
            if(rng2 == 2)
                l2 = LC;
            if(rng2 == 3)
                l2 = LL;
            if(rng2 == 4)
                l2 = LB;

            if(rng3 == 1)
                l3 = LH;
            if(rng3 == 2)
                l3 = LC;
            if(rng3 == 3)
                l3 = LL;
            if(rng3 == 4)
                l3 = LB;
        }
        else if(loot < iron)
        {
            if(rng == 1)
                l1 = IH;
            if(rng == 2)
                l1 = IC;
            if(rng == 3)
                l1 = IL;
            if(rng == 4)
                l1 = IB;
            
            if(rng2 == 1)
                l2 = IH;
            if(rng2 == 2)
                l2 = IC;
            if(rng2 == 3)
                l2 = IL;
            if(rng2 == 4)
                l2 = IB;

            if(rng3 == 1)
                l3 = IH;
            if(rng3 == 2)
                l3 = IC;
            if(rng3 == 3)
                l3 = IL;
            if(rng3 == 4)
                l3 = IB;
        }
        else if(loot < diamond)
        {
            if(rng == 1)
                l1 = DH;
            if(rng == 2)
                l1 = DC;
            if(rng == 3)
                l1 = DL;
            if(rng == 4)
                l1 = DB;
            
            if(rng2 == 1)
                l2 = DH;
            if(rng2 == 2)
                l2 = DC;
            if(rng2 == 3)
                l2 = DL;
            if(rng2 == 4)
                l2 = DB;

            if(rng3 == 1)
                l3 = DH;
            if(rng3 == 2)
                l3 = DC;
            if(rng3 == 3)
                l3 = DL;
            if(rng3 == 4)
                l3 = DB;
        }
        else if(loot < netherite)
        {
            if(rng == 1)
                l1 = NH;
            if(rng == 2)
                l1 = NC;
            if(rng == 3)
                l1 = NL;
            if(rng == 4)
                l1 = NB;
            
            if(rng2 == 1)
                l2 = NH;
            if(rng2 == 2)
                l2 = NC;
            if(rng2 == 3)
                l2 = NL;
            if(rng2 == 4)
                l2 = NB;

            if(rng3 == 1)
                l3 = NH;
            if(rng3 == 2)
                l3 = NC;
            if(rng3 == 3)
                l3 = NL;
            if(rng3 == 4)
                l3 = NB;
        }
        t.bigGive(l1,l2,l3,t);
        Debug.Log(t.teamName + " looted: " + l1.itemName + ", " + l2.itemName + ", " + l3.itemName);
    }
}
