using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Team : MonoBehaviour
{
	public string teamName;
	public Player p1;
	public Player p2;
	public Player p3;

	public void bigGive(Loot l1, Loot l2, Loot l3, Team t)
	{
		Player[] players = new Player[3];
		players = t.randomOrder(t);

		
		if(players[0].canGive(l1))
		{
			players[0].Give(l1);
		}
		else if(players[1].canGive(l1))
		{
			players[1].Give(l1);
		}
		else
		{
			players[2].Give(l1);
		}


		if(players[1].canGive(l2))
		{
			players[1].Give(l2);
		}
		else if(players[2].canGive(l2))
		{
			players[2].Give(l2);
		}
		else
		{
			players[0].Give(l2);
		}

		if(players[2].canGive(l3))
		{
			players[2].Give(l3);
		}
		else if(players[0].canGive(l3))
		{
			players[0].Give(l3);
		}
		else
		{
			players[1].Give(l3);
		}
	}

	public Player[] randomOrder(Team t)
	{
		Player[] players = new Player[3];
		int one = 0;
		int two = 0;
		int three = 0;
		while(one == two || one == three || two == three)
		{
			one = Random.Range(0,3);
			two = Random.Range(0,3);
			three = Random.Range(0,3);
		}
		players[one] = t.p1;
		players[two] = t.p2;
		players[three] = t.p3;
		return(deadEnd(players)); 
	}

	public Player[] deadEnd(Player[] players)
	{
		Player temp = new Player();
		if (!players[0].alive)
		{
			temp = players[0];
			players[0] = players[2];
			players[2] = temp;
		}
		else if(!players[1].alive)
		{
			temp = players[1];
			players[1] = players[2];
			players[2] = temp;
		}
		return players;
	}
}
