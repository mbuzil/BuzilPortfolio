using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Art : Player
{
    public Art()
    {
        ign = "Art";
        melee = 1;
        archery = 6;
        mining = 2;
    }
}
