using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MitchellReeves : Player
{
    public MitchellReeves()
    {
        ign = "MitchellReeves";
        melee = 6;
        archery = 4;
        mining = 2;
    }
}
