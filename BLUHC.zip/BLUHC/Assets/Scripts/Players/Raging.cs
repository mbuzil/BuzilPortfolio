using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Raging : Player
{
    public Raging()
    {
        ign = "Raging";
        melee = 3;
        archery = 5;
        mining = 5;
    }
}
