using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Purple : Player
{
    public Purple()
    {
        ign = "Purple";
        melee = 4;
        archery = 6;
        mining = 3;
    }
}
