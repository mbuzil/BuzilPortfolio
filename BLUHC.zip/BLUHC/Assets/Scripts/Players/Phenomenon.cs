using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Phenomenon : Player
{
    public Phenomenon()
    {
        ign = "Phenomenon";
        melee = 1;
        archery = 2;
        mining = 5;
    }
}
