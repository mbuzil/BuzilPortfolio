using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Marbles : Player
{
    public Marbles()
    {
        ign = "Marbles";
        melee = 5;
        archery = 4;
        mining = 3;
    }
}
