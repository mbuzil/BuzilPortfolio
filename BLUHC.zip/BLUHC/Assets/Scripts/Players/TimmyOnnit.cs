using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimmyOnnit : Player
{
    public TimmyOnnit()
    {
        ign = "TimmyOnnit";
        melee = 6;
        archery = 4;
        mining = 2;
    }
}
