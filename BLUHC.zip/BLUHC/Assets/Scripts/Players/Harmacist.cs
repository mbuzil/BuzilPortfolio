using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Harmacist : Player
{
    public Harmacist()
    {
        ign = "Harmacist";
        melee = 3;
        archery = 5;
        mining = 5;
    }
}
