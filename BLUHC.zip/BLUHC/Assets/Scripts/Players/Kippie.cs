using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Kippie : Player
{
    public Kippie()
    {
        ign = "Kippie";
        melee = 2;
        archery = 2;
        mining = 6;
    }
}
