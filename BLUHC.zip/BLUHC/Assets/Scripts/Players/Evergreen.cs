using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Evergreen : Player
{
    public Evergreen()
    {
        ign = "Evergreen";
        melee = 4;
        archery = 1;
        mining = 2;
    }
}
