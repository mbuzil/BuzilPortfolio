using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spideyfan : Player
{
    public Spideyfan()
    {
        ign = "SpideyFan206";
        melee = 2;
        archery = 3;
        mining = 6;
    }
}
