using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Four : Player
{
    public Four()
    {
        ign = "Four";
        melee = 4;
        archery = 6;
        mining = 6;
    }
}
