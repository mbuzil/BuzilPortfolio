using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flower : Player
{
    public Flower()
    {
        ign = "Flower";
        melee = 1;
        archery = 1;
        mining = 2;
    }
}
