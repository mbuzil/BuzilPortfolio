using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WalmartPanda : Player
{
    public WalmartPanda()
    {
        ign = "WalmartPanda";
        melee = 3;
        archery = 6;
        mining = 5;
    }
}
