using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Powatrip : Player
{
    public Powatrip()
    {
        ign = "Powatrip";
        melee = 4;
        archery = 1;
        mining = 4;
    }
}
