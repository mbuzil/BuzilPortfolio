using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrDisco : Player
{
    public DrDisco()
    {
        ign = "DrDisco";
        melee = 5;
        archery = 2;
        mining = 5;
    }
}
