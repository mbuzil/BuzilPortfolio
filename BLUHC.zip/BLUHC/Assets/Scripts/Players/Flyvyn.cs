using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flyvyn : Player
{
    public Flyvyn()
    {
        ign = "Flyvyn";
        melee = 2;
        archery = 6;
        mining = 2;
    }
}
