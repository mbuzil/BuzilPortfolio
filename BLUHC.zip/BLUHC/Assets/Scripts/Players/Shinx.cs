using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shinx : Player
{
    public Shinx()
    {
        ign = "Shinx";
        melee = 3;
        archery = 6;
        mining = 4;
    }
}
