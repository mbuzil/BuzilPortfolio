using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Two : Player
{
    public Two()
    {
        ign = "Two";
        melee = 3;
        archery = 2;
        mining = 5;
    }
}
