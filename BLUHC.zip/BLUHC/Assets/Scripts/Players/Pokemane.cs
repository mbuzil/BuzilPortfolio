using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pokemane : Player
{
    public Pokemane()
    {
        ign = "Pokemane";
        melee = 5;
        archery = 6;
        mining = 3;
    }
}
