using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ludvig : Player
{
    public Ludvig()
    {
        ign = "Ludvig";
        melee = 6;
        archery = 6;
        mining = 6;
    }
}
