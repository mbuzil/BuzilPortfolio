using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Doff : Player
{
    public Doff()
    {
        ign = "Doff";
        melee = 5;
        archery = 6;
        mining = 2;
    }
}
