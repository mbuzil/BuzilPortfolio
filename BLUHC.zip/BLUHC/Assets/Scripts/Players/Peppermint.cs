using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Peppermint : Player
{
    public Peppermint()
    {
        ign = "Peppermint";
        melee = 3;
        archery = 4;
        mining = 3;
    }
}
