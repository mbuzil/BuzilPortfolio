using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Okay : Player
{
    public Okay()
    {
        ign = "Okay";
        melee = 5;
        archery = 3;
        mining = 6;
    }
}
