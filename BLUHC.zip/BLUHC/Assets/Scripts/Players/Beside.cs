using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Beside : Player
{
    public Beside()
    {
        ign = "Beside";
        melee = 4;
        archery = 1;
        mining = 3;
    }
}
