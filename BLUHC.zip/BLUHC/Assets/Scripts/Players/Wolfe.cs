using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wolfe : Player
{
    public Wolfe()
    {
        ign = "Wolfe";
        melee = 4;
        archery = 5;
        mining = 3;
    }
}
