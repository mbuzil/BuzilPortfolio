using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Guts : Player
{
    public Guts()
    {
        ign = "Guts";
        melee = 1;
        archery = 2;
        mining = 5;
    }
}
