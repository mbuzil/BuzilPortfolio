using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blossom : Player
{
    public Blossom()
    {
        ign = "Blossom";
        melee = 6;
        archery = 1;
        mining = 4;
    }
}
