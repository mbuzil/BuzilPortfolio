using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pyrocat : Player
{
    public Pyrocat()
    {
        ign = "Pyrocat";
        melee = 4;
        archery = 1;
        mining = 5;
    }
}
