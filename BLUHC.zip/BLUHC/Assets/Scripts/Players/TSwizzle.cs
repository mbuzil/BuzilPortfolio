using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TSwizzle : Player
{
    public TSwizzle()
    {
        ign = "TSwizzle";
        melee = 4;
        archery = 2;
        mining = 5;
    }
}
