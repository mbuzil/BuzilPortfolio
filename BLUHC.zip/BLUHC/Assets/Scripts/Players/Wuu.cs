using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wuu : Player
{
    public Wuu()
    {
        ign = "Wuu";
        melee = 2;
        archery = 1;
        mining = 6;
    }
}
