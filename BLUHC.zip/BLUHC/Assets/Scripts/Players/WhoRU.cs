using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WhoRU : Player
{
    public WhoRU()
    {
        ign = "WhoRU";
        melee = 2;
        archery = 1;
        mining = 5;
    }
}
