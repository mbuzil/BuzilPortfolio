using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sticky : Player
{
    public Sticky()
    {
        ign = "Sticky";
        melee = 4;
        archery = 3;
        mining = 4;
    }
}
