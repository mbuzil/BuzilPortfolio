using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chaddd : Player
{
    public Chaddd()
    {
        ign = "CHADDDD";
        melee = 3;
        archery = 3;
        mining = 3;
    }
}
