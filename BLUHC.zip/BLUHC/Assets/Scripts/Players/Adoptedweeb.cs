using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Adoptedweeb : Player
{
    public Adoptedweeb()
    {
        ign = "Adopt3dw33B";
        melee = 5;
        archery = 6;
        mining = 5;
    }
}
