using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetherliteChestplate : Loot
{
    public NetherliteChestplate()
    {
        itemName = "Netherite Chestplate";
        itemType = "Chestplate";
        lootCoefficient = 0.4f;
        resourceCoefficient = 4;
    }
}
