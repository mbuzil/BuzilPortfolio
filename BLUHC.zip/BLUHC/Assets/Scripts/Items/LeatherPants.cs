using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeatherPants : Loot
{
    public LeatherPants()
    {
        itemName = "Leather Pants";
        itemType = "Leggings";
        lootCoefficient = 0.3f;
        resourceCoefficient = 1;
    }
}
