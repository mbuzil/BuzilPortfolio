using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IronChest : Loot
{
    public IronChest()
    {
        itemName = "Iron Chestplate";
        itemType = "Chestplate";
        lootCoefficient = 0.4f;
        resourceCoefficient = 2;
    }
}
