using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IronBoots : Loot
{
    public IronBoots()
    {
        itemName = "Iron Boots";
        itemType = "Boots";
        lootCoefficient = 0.15f;
        resourceCoefficient = 2;
    }
}
