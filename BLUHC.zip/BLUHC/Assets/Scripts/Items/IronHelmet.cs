using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IronHelmet : Loot
{
    public IronHelmet()
    {
        itemName = "Iron Helmet";
        itemType = "Helmet";
        lootCoefficient = 0.15f;
        resourceCoefficient = 2;
    }
}
