using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiamondLeggings : Loot
{
    public DiamondLeggings()
    {
        itemName = "Diamond Leggings";
        itemType = "Leggings";
        lootCoefficient = 0.3f;
        resourceCoefficient = 3;
    }
}
