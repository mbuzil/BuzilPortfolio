using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeatherBoots : Loot
{
    public LeatherBoots()
    {
        itemName = "Leather Boots";
        itemType = "Boots";
        lootCoefficient = 0.15f;
        resourceCoefficient = 1;
    }
}
