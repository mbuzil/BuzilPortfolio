using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeatherChest : Loot
{
    public LeatherChest()
    {
        itemName = "Leather Tunic";
        itemType = "Chestplate";
        lootCoefficient = 0.4f;
        resourceCoefficient = 1;
    }
}
