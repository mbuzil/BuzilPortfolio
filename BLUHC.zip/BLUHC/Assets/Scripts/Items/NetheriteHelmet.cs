using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetheriteHelmet : Loot
{
    public NetheriteHelmet()
    {
        itemName = "Netherite Helmet";
        itemType = "Helmet";
        lootCoefficient = 0.15f;
        resourceCoefficient = 4;
    }
}
