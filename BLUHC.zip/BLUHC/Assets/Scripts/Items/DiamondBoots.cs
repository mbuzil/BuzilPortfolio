using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiamondBoots : Loot
{
    public DiamondBoots()
    {
        itemName = "Diamond Boots";
        itemType = "Boots";
        lootCoefficient = 0.15f;
        resourceCoefficient = 3;
    }
}
