using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Empty : Loot
{
    public Empty()
    {
        itemName = "Empty";
        itemType = "Empty";
        lootCoefficient = 0f;
        resourceCoefficient = 0;
    }
}
