using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiamondChest : Loot
{
    public DiamondChest()
    {
        itemName = "Diamond Chestplate";
        itemType = "Chestplate";
        lootCoefficient = 0.4f;
        resourceCoefficient = 3;
    }
}
