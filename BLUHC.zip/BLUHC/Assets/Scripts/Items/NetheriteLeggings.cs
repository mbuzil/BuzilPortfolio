using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetheriteLeggings : Loot
{
    public NetheriteLeggings()
    {
        itemName = "Netherite Leggings";
        itemType = "Leggings";
        lootCoefficient = 0.3f;
        resourceCoefficient = 4;
    }
}
