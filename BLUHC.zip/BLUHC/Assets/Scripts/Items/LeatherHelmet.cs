using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeatherHelmet : Loot
{
    public LeatherHelmet()
    {
        itemName = "Leather Cap";
        itemType = "Helmet";
        lootCoefficient = 0.15f;
        resourceCoefficient = 1;
    }
}
