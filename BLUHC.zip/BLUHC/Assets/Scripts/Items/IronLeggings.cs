using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IronLeggings : Loot
{
    public IronLeggings()
    {
        itemName = "Iron Leggings";
        itemType = "Leggings";
        lootCoefficient = 0.3f;
        resourceCoefficient = 2;
    }
}
