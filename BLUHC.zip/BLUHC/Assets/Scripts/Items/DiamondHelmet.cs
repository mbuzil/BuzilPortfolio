using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiamondHelmet : Loot
{
    public DiamondHelmet()
    {
        itemName = "Diamond Helmet";
        itemType = "Helmet";
        lootCoefficient = 0.15f;
        resourceCoefficient = 3;
    }
}
