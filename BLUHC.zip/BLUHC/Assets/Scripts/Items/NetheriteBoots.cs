using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetheriteBoots : Loot
{
    public NetheriteBoots()
    {
        itemName = "Netherite Boots";
        itemType = "Boots";
        lootCoefficient = 0.15f;
        resourceCoefficient = 4;
    }
}
