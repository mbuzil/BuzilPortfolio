using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Combat : MonoBehaviour
{

    Team t1;
    [SerializeField] Team t2;
    [SerializeField] GameObject admin;

    int combatCoefficient1;
    int combatCoefficient2;

    void Update()
    {
        t1 = admin.GetComponent<Administrator>().getTeam();
    }

    public void Fight()
    {
        Debug.Log(t1.teamName + " is fighting " + t2.teamName);
        if(t1.teamName != t2.teamName)
        {
        combatCoefficient1 = getCoefficient(t1);
        combatCoefficient2 = getCoefficient(t2);

        if(combatCoefficient1 > combatCoefficient2)
        {
            Debug.Log(t1 + " Has won the fight");
        }
        else if(combatCoefficient2 > combatCoefficient1)
        {
            Debug.Log(t2 + " Has won the fight");
        }
        else
        {
            Debug.Log(t1 + " and " + t2 + " Has tied");
        }
        divideDamage(combatCoefficient1, t2, t1);
        divideDamage(combatCoefficient2, t1, t2);

        Debug.Log(t1 + " took " + combatCoefficient2 + " damage");
        Debug.Log(t2 + " took " + combatCoefficient1 + " damage");

        combatCoefficient1 = 0;
        combatCoefficient2 = 0;
        }
        else
            Debug.Log("No Friendly Fire");
    }

    public int getCoefficient(Team t1)
    {
        int finalnum = 0;
        int f1 = 0;
        int f2 = 0;
        int f3 = 0;
        int f4 = 0;
        int f5 = 0;
        int f6 = 0;
        int f7 = 0;
        int f8 = 0;
        int f9 = 0;
        
        if(t1.p1.alive == true)
        {
            f1 = Random.Range(1, t1.p1.melee*2);
            f2 = Random.Range(1, t1.p1.archery*2);
            f7 = Random.Range(1, t1.p1.mining/2);
        }

        if(t1.p2.alive == true)
        {
            f3 = Random.Range(1, t1.p2.melee*2);
            f4 = Random.Range(1, t1.p2.archery*2);
            f8 = Random.Range(1, t1.p1.mining/2);
        }

        if(t1.p3.alive == true)
        {
            f5 = Random.Range(1, t1.p3.melee*2);
            f6 = Random.Range(1, t1.p3.archery*2);
            f9 = Random.Range(1, t1.p1.mining/2);
        }

        if(f1>f2)
            finalnum += f1;
        else
            finalnum += f2;
        if(f3>f4)
            finalnum += f3;
        else
            finalnum += f4;
        if(f5>f6)
            finalnum += f5;
        else
            finalnum += f6;

        finalnum+= f7+f8+f9;
        return finalnum * 2;
    }

    public void divideDamage(int cc, Team t, Team t2)
    {
        int ran1 = 0;
        int ran2 = 0;
        int ran3 = 0;
        float arm1 = 0f;
        float arm2 = 0f;
        float arm3 = 0f;

        if(t.p1.alive)
            ran1 = (int) Random.Range(0, cc);
        if(t.p2.alive)
            ran2 = (int) Random.Range(0, cc-ran1);
        if(t.p3.alive)
            ran3 = cc-ran1-ran2;
        if(ran1>0)
            arm1 = (t.p1.armorCoefficient - 1) * 5 / 100;
        if(ran2>0)
            arm2 = (t.p2.armorCoefficient - 1) * 5 / 100;
        if(ran3>0)
            arm3 = (t.p3.armorCoefficient - 1) * 5 / 100;

        Debug.Log("Total damage from " + t.teamName + ": " + cc);
        int dmg1 = (int)(ran1 * (1-arm1));
        int dmg2 = (int)(ran2 * (1-arm2));
        int dmg3 = (int)(ran3 * (1-arm3));
        t.p1.combatDMG(dmg1);
        t.p2.combatDMG(dmg2);
        t.p3.combatDMG(dmg3);
        Player[] plys = t2.randomOrder(t2);
        
        if(t.p1.hp <= 0 && t.p1.alive){
            if(plys[0].alive)
            {
                plys[0].gotKill();
            }
            else if(plys[1].alive)
            {
                plys[1].gotKill();
            }
            else
            {
                plys[2].gotKill();
            }
            kill(t.p1);
        }
        if(t.p2.hp <= 0 && t.p2.alive)
        {
            if(plys[1].alive)
            {
                plys[1].gotKill();
            }
            else if(plys[2].alive)
            {
                plys[2].gotKill();
            }
            else
            {
                plys[0].gotKill();
            }
            kill(t.p2);
        }
        if(t.p3.hp <= 0 && t.p3.alive)
        {
            if(plys[2].alive)
            {
                plys[2].gotKill();
            }
            else if(plys[1].alive)
            {
                plys[1].gotKill();
            }
            else
            {
                plys[0].gotKill();
            }
            kill(t.p3);
        }

        if(t.p1.hp+t.p2.hp+t.p3.hp == 0)
            admin.GetComponent<Administrator>().delTeam(t);
    }

    public void killAll(Team t)
    {
        kill(t.p1);
        kill(t.p2);
        kill(t.p3);
    }

    public void kill(Player p)
    {
        p.alive = false;
        p.melee = 0;
        p.archery = 0;
        p.mining = 0;
        p.hp = 0;
        Debug.Log(p.ign + " has died");
    }
}
